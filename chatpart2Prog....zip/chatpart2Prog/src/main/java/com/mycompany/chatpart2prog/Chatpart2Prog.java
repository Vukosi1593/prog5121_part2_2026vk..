/*

* Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license

*/
 
package com.mycompany.chatpart2prog;
import java.util.Scanner;
import java.util.Random;
/**
*
* @author vukosi.shivuri

*/
 
public class Chatpart2Prog{
 
    public static void main(String[] args) {

        //Below code is for a scanner to read the user input 

        Scanner input = new Scanner(System.in);
        System.out.println("Welcome to QuickChat.");
 
        //This is for registration object to access validation methods 
        Registration registration = new Registration();
        
        System.out.println("---> Registration <---");
 
        //Below is for asking user to enter their login details

        System.out.println("Please, Enter your First Name: ");

        String firstName = input.nextLine();
 
        System.out.println("Please, Enter your Last Name: ");

        String lastName = input.nextLine();
 
        /* This is for user to enter login details */
 
        String username;

        do{

            System.out.println("Enter your username: " + "(must contain an underscore, and be less than 5 characters)");

            username = input.nextLine();

            System.out.println(registration.returnUserNameMessage(username));

        }while (!registration.checkUserName(username));
 
        String password;

        do{

            System.out.println("Enter your password: " + "(password must be: "

                    + "at least 8 characters long, "

                    + "contain a capital letter, "

                    + "contain a number,"

                    + "contain a special character.)");

            password = input.nextLine();

            System.out.println(registration.returnCheckPasswordMessage(password));

        }while (!registration.checkPasswordComplexity(password));
 
        String cellPhoneNumber;

        do{

            System.out.println("Enter your cellphone number: " + " (must contain a international country code(+27)");

            cellPhoneNumber = input.nextLine();

            System.out.println(registration.returncheckCellPhoneNumberMessage(cellPhoneNumber));

        }while (!registration.checkCellPhoneNumber(cellPhoneNumber));
 
        System.out.println("---> Login <---");

        //Login object with registration credentials

        Login login = new Login(username, password);
 
        //this code is for variable to track login status

        boolean loggedIn = false;
 
        //loop will continue until user enters the right credentials

        while (!loggedIn) {

            System.out.println("Enter your username: ");

            String loginUserName = input.nextLine();
 
            System.out.println("Enter your password: ");

            String loginPassword = input.nextLine();
 
            //check if entered credentials match the stored credentials

            if (login.loginUser(loginUserName, loginPassword)) {

                System.out.println("Welcome " + firstName + " " + lastName + ", " +"it is great to see you again.");

                loggedIn = true;

            } else {

                System.out.println("Username or password incorrect, please try again.");

            }
 
        }
        
     // set maximun messages
     System.out.print("Enter how many messages you wish to enter for this session: ");
     int maxMessages = Integer.parseInt(input.nextLine());
     
     int messagesSentCount = 0;
     
     //Message tool class to use vatidation tools
     Message messageTool = new Message();
        //added loop here
boolean isRunning = true;
        while (isRunning) {
            System.out.println("\n--- QuickChat Main Menu ---");
            System.out.println("1. Send a Message");
            System.out.println("2. View Profile Information");
            System.out.println("3. Show Recently sent messages");
            System.out.println("4. Quit");
            System.out.print("Choose an option: ");
            String choice = input.nextLine();

            switch (choice) {
                case "1":
                    //check if the maximum message limit has been met
                    if (messagesSentCount >= maxMessages){
                        System.out.println("Maximum message limit of " + maxMessages + " reached for this session.");
                        break;
                    }
                    
                    System.out.print("Enter recipient cell number: ");
                    String recipient = input.nextLine();
                    
                 //Validate phone number format
                 System.out.println(messageTool.checkRecipientCell(recipient));
                 
                    System.out.print("Enter your message (max 250 characters): ");
                    String msg = input.nextLine();
                    
                    if (msg.length() > 250) {
                        int excess = msg.length() - 250;
                        System.out.println("Message exceeds 250 characters by " + excess + "; please reduce the size.");
                        break; 
                    } else {
                        System.out.println("Message ready to send.");
                    }
               
                    //genereting unique 10 digit ID
                    Random rand = new Random();
                    long trackingId = 1000000000L + (long)(rand.nextDouble() * 9000000000L);
                    String messageID = String.valueOf(trackingId);
                    
                    // Generate Hash representation using business rules
                    String messageHash = messageTool.createMessageHash(messageID, messagesSentCount, msg);
                    
                    //when user chooses to send message, options must appear after message is drafted. such options must be 1. send message, 2. disregard message, 3. store message
                    System.out.println("\nWhat would you like to do with this messag:?  select an option: ");
                    System.out.println("1. Send the Message");
                    System.out.println("2. Disregard message");
                    System.out.println("3. Store Message to send later");
                    System.out.print("choose an option: ");
                    String actionChoice = input.nextLine();
                    
                    String actionStatus = messageTool.SentMessage(actionChoice);
                    System.out.println(actionStatus);
                    
                    if (actionChoice.equals("1") || actionChoice.equals("3")) {
                        // Increment tracking totals
                        messagesSentCount++;
                        
                        //Explicit execution print statement order
                        System.out.println("\n---> Message Details <---");
                        System.out.println("Message ID: " + messageID);
                        System.out.println("Message Hash: " + messageHash);
                        System.out.println("Recipient: " + recipient);
                        System.out.println("Message: " + msg);
                    }

                    break;
                case "2":
                    System.out.println("\n---> User Profile <---");
                    System.out.println("Name: " + firstName + " " + lastName);
                    System.out.println("Username: " + username);
                    System.out.println("Phone: " + cellPhoneNumber);
                    break;
                    
                case "3":
                    System.out.print("Coming soon");
                    break;
                    
                case "4":
                    System.out.println("Logging out... Goodbye!");
                    isRunning = false;
                    break;

                default:
                    System.out.println("Invalid option. Please try again.");
       }
    }
 
 }
   //User registration
   

   public static class Registration {

        //username validation

        public boolean checkUserName(String username){
 
            if(username.contains("_") && username.length()<=5) {

                return true;

            } else {

                return false;
 
            }

        }

        //Method returning the correct message

        public String returnUserNameMessage(String username){

            if (checkUserName(username)) {

                return "Username successfully captured.";

            } else {

                return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
 
            }

        }

        //the method to validate the password

        public boolean checkPasswordComplexity(String password){
 
            if (password.length()>=8 &&

                    password.matches(".*[A-Z].*") &&

                    password.matches(".*[0-9].*") &&

                    password.matches(".*[^a-zA-Z0-9].*")){

                return true;

            } else {

                return false;

            }

        }

        //Method returning the correct message

        public String returnCheckPasswordMessage(String password){

            if (checkPasswordComplexity(password)){

                return "Password successfully captured.";

            } else {

                return "Password is not correctly formatted,please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";

            }

        }

        //cellphone number validation

        public boolean checkCellPhoneNumber(String cellPhoneNumber){

            if (cellPhoneNumber.matches("\\+27\\d{9}")) {

                return true;

            } else {

                return false;

            }
 
        }

        //Method returning the correct message

        public String returncheckCellPhoneNumberMessage(String cellPhoneNumber) {

            if (checkCellPhoneNumber(cellPhoneNumber)){

                return "Cell phone number successfully added.";

            } else {

                return "Cell phone number incorrectly formatted or does not contain international code(+27); please correct the number and try again.";

            }

        }

    }
 
    /* Below code is for Public class User information */
 
    public static class User {

        //Instance variables used to store user information

        private String username;

        private String password;

        private String cellPhoneNumber;
 
        //constructor to fill those variables for a new user

        public User(String username, String password, String cellPhoneNumber){

            this.username = username;

            this.password = password;

            this.cellPhoneNumber = cellPhoneNumber;

        }

    }
 
 
/* below public class is for user data storing */
 
    

    public static class Login {

        /*Instance variables used to store user credentials */

        private String storedUserName;

        private String storedPassword;
 
        //constructor to fill those variables

        public Login(String storedUserName, String storedPassword) {

            this.storedUserName = storedUserName;

            this.storedPassword = storedPassword;

        }

        //Method to verify credentials

        public boolean loginUser(String enteredUserName, String enteredPassword){

            if (storedUserName.equals(enteredUserName) && storedPassword.equals(enteredPassword)) {

                return true;

            } else {

                return false;

            }
 
        }

        //Method to return the correct message

        public String returnLoginStatus(String enteredUserName, String enteredPassword,

                                        String firstName, String lastName) {

            if(loginUser(enteredUserName, enteredPassword)) {

                return "Welcome " + firstName + " " + lastName + ", " +"it is great to see you again.";

            } else

             return "Username or password incorrect, please try again.";
            
        }
        
    }
            
            public static class Message {

        //Validates ID string length restrictions 
        public boolean checkMessageID(String messageID) {
            return messageID != null && messageID.length() <= 10;
        }

        //Validates recipient cell configurations 
        public String checkRecipientCell(String cellPhoneNumber) {
            if (cellPhoneNumber.matches("\\+27\\d{9}") || cellPhoneNumber.matches("0\\d{9}")) {
                return "Cell phone number successfully captured.";
            } else {
                return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }

    }
 // Extracts details and cleans non-alphanumeric text for '00:0:HITONIGHT')
        public String createMessageHash(String messageID, int messageNum, String message) {
            String firstTwoDigits = (messageID != null && messageID.length() >= 2) ? messageID.substring(0, 2) : "00";
            
            String[] words = message.trim().split("\\s+");
            String firstWord = words.length > 0 ? words[0] : "";
            String lastWord = words.length > 0 ? words[words.length - 1] : "";
            
            String combinedWords = (firstWord + lastWord).replaceAll("[^a-zA-Z0-9]", "");
            
            return (firstTwoDigits + ":" + messageNum + ":" + combinedWords).toUpperCase();
        }
            
//Tracks selection action feedback paths
public String SentMessage(String choice) {
    switch (choice) {
      case "1":
        return "Message successfully sent.";
      case "2":
        return "Press 0 to delete the message.";
      case "3":
        return "Message successfully stored.";
      default:
        return "Unknown choice selection processed.";
            }
        }
//Required logging stub from structural details specification table
public String printMessages() {
    return "Returning all processed application message entries.";
      }
//Wraps tracking values to hand out application context aggregates
        public int returnTotalMessagess(int currentTotalCount) {
            return currentTotalCount;
    }

//Structural pipeline placeholder for prospective JSON research requirement tasks
        public void storeMessage() {
// Future placeholder method hook context
        }
    }
}

 