/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package chatpart2prog;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author vukosi.shivuri
 */
public class chatpart2progTest {
    
//Test of message length validation
@Test
    public void testCheckMessageLength_Success() {
        System.out.println("checkMessageLength - Success"); 
        
//Setup text safely under 250 characters
        String validMessage = "Hi Mike, can you join us for dinner tonight?";
// Business logic check simulation matching your runtime behavior
        String result;
        if (validMessage.length() <= 250) {
            result = "Message ready to send.";
        } else {
            result = "Message exceeds 250 characters by " + (validMessage.length() - 250) + "; please reduce the size.";
        }
        
        assertEquals("Message ready to send.", result);
    }
//test message length validation
    @Test
    public void testCheckMessageLength_Failure() {
        System.out.println("checkMessageLength - Failure");
        
// Generate a string that is intentionally 252 characters long
        StringBuilder longMsgBuilder = new StringBuilder();
        for (int i = 0; i < 252; i++) {
            longMsgBuilder.append("a");
        }
        String invalidMessage = longMsgBuilder.toString();
        
        String result;
        if (invalidMessage.length() <= 250) {
            result = "Message ready to send.";
        } else {
            result = "Message exceeds 250 characters by " + (invalidMessage.length() - 250) + "; please reduce the size.";
        }
//Expected value based on 250 characters
String expectedMessage = "Message exceeds 250 characters by 2; please reduce the size.";
        assertEquals(expectedMessage, result);
        
    }
        
 //Test of checkRecipientCell method-success
@Test
    public void testCheckRecipientCell_Success() {
        System.out.println("checkRecipientCell - Success");
        Chatpart2Prog.Message messageTool = new Chatpart2Prog.Message();
        
        // Valid test phone number from image 6
        String validCell = "+27718693002"; 
        String expected = "Cell phone number successfully captured.";
        
        String actual = messageTool.checkRecipientCell(validCell);
        assertEquals(expected, actual);
        
    }
//Test of checkRecipientCell method - Failure 
@Test
    public void testCheckRecipientCell_Failure() {
        System.out.println("checkRecipientCell - Failure");
        Chatpart2Prog.Message messageTool = new Chatpart2Prog.Message();
        
        // Invalid test phone number from image 7 (Does not match international pattern +27)
        String invalidCell = "08575975889"; 
        String expected = "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        
        String actual = messageTool.checkRecipientCell(invalidCell);
        assertEquals(expected, actual);
    }
 //Test of createMessageHash method - Match Test Case 1

 @Test
    public void testCreateMessageHash_Validity() {
        System.out.println("createMessageHash");
        Chatpart2Prog.Message messageTool = new Chatpart2Prog.Message();
        
        String mockMessageID = "0012345678"; // 10 digit ID starting with 00
        int messageCount = 0;
        String messageBody = "Hi Mike, can you join us for dinner tonight?";
        
        // The method isolates first two digits ("00"), counter (0), 
        // and cleans/combines first word ("Hi") and last word ("tonight?") -> "HITONIGHT"
        String expectedHash = "00:0:HITONIGHT";
        
        String actualHash = messageTool.createMessageHash(mockMessageID, messageCount, messageBody);
        assertEquals(expectedHash, actualHash);
    }   

    }
    
    

